import { useState } from 'react';
import './App.css';

function App() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const handlebar = (event) => {
    event.preventDefault();
    console.log(name);
    console.log(email);
  }

  return (
    <>
      <style>
        {`
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #eaeaea;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
          }

          .form-container {
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            padding: 30px;
            width: 400px;
            text-align: center;
          }

          h2 {
            margin-bottom: 20px;
            color: #333;
          }

          form {
            display: flex;
            flex-direction: column;
          }

          input {
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            transition: border-color 0.3s;
          }

          input:focus {
            border-color: #007bff;
            outline: none;
          }

          .button-container {
            margin-top: 20px;
          }

          button {
            padding: 12px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
          }

          button:hover {
            background-color: #218838;
          }
        `}
      </style>
      <div className="form-container">
        <h2>FORM</h2>
        <form onSubmit={handlebar}>
          <input 
            onChange={(e) => setName(e.target.value)} type="text"  placeholder='Your Name' />
          <input 
            onChange={(e) => setEmail(e.target.value)} type="email" placeholder='Your Email' />
          <div className="button-container">
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>
    </>
  );
}

export default App;
